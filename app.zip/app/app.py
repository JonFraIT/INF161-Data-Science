import pandas as pd
import pickle

from flask import Flask, request, render_template
from waitress import serve

app = Flask(__name__)

# read and prepare model
model = pickle.load(open('model.pkl', 'rb'))

@app.route('/')
def home():
    return render_template('./index.html')

@app.route('/predict', methods=['POST'])
def predict():
    '''
    Rendering results on HTML
    '''
    # get data
    features = dict(request.form)
    features1 = {'Date':features["datePredict"], 'Hour':features["hour"], 'Lufttemperatur':features["lufttemperatur"]}

    # handle no weather data, default set value to 5
    if features1['Lufttemperatur'] == '':
        features1['Lufttemperatur'] = 5

    # create dataframe
    df = pd.DataFrame(features1, index=[0])
    df['Datetime'] = pd.to_datetime(df['Date']+df['Hour'], format='%Y-%m-%d%H:%M') 
    df = df.drop(['Date', 'Hour'], axis=1)
    df = df.set_index('Datetime')
    df['Hour'] = df.index.hour 
    df['Day'] = df.index.dayofweek 
    df['Day'] = df['Day'] < 5 
    df['Day'] = df['Day'].astype(int)
    df = df.rename(columns={'Day':'isWeekday'})
    df['Month'] = df.index.month
    df[['Hour', 'isWeekday', 'Month']] = df[['Hour', 'isWeekday', 'Month']].astype('object')

    # make prediction
    prediction = model.predict(df)
    prediction = round(prediction[0])

    return render_template(
        './index.html',
        prediction_text= f'Prediction for {df.index[0].day}. {df.index[0].month_name()}. {df.index[0].year} at {df.index[0].hour}:00 : {prediction}')


if __name__ == '__main__':
    serve(app, host='0.0.0.0', port=8080)